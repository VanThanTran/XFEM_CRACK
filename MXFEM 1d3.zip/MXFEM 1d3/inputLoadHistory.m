function loadIter = inputLoadHistory(iter)

% loadIter(1,:) = [Sxx_max;Sxy_max;Syy_max;Sxx_min;Sxy_min;Syy_min;Number of cycles]

% loadIter = [];  % old codes


loadIter(1,:) = [0 ; 0; 78.62e6; 0; 0; 1e3; 50];   % update