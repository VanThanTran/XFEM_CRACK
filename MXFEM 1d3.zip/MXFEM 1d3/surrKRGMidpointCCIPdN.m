% Written By: Matthew Jon Pais, University of Florida (2011)
% Website: www.matthewpais.com
% Email: mpais@ufl.edu, matthewjpais@gmail.com

% Requires use of SURROGATES Toolbox
% FAC Viana, SURROGATES Toolbox User's Guide, Version 2.1,
% http:/sites.google.com/site/fchegury/surrogatestoolbox, 2010.

% Problem is that of fatigue crack growth for a center crack in an infinite
% plate. It is assumed that a constant number of elapsed cycles, dN has 
% been used to incrementally create a N-dK history. A kriging surrogate is 
% fit to the current N-dK history and used to calculate the magnitude of 
% crack growth for a given number of elapsed cycles dN using the midpoint 
% integration method.

clear all; close all; clc; format short;

% Preliminaries
ai = 0.01;                      % Initial crack length [m]
m  = 3.59;                      % Paris model exponent
C  = 3.15E-11;                  % Paris model constant
S  = 78.6;                      % Applied stress [MPa]
dN = 100;                       % Integration step size
Ni = 3*dN;                      % Number of initial data points before kriging

% Theoretical solution for N-a relationship
N  = 0:dN:22300;                % Cycles to failure
a  = (N*C*(1-m/2)*(S*sqrt(pi)).^m+ai^(1-m/2)).^(1/(1-m/2));
dK = S.*sqrt(pi*a);             % Stress intensity for each cycle

% Initial data points before kriging starts
aKRG = a(1:length(dN:dN:(Ni+dN)));
NS   = 0:dN:Ni;
kKRG = dK(1:length(0:dN:Ni));

% Calculate crack growth magnitude from N-dK history
for i = length(kKRG):length(N)
    optionKRG = srgtsKRGSetOptions(NS',kKRG');
    surrKRG   = srgtsKRGFit(optionKRG);         % Fit surrogat to current N-dK history
    
    MP = max(NS)+dN/2;                          % Midpoint between cycles
    Kk = srgtsKRGEvaluate(MP,surrKRG);          % Kriging estimate of dK
    
    daKRG     = dN*C*(Kk)^m;                    % Predicted crack growth increment
    aKRG(i+1) = aKRG(i)+daKRG;
    kKRG(i+1) = S*sqrt(pi*aKRG(i+1));
    NS(i+1)   = NS(i)+dN;
end

del = length(aKRG);
aKRG(del) = [];

figure; hold on; grid on;
plot(N,a,'k')
plot(N,aKRG,':r')
xlabel('Number of Cycles')
ylabel('Crack Length')
deltaN = ['\DeltaN = ' int2str(dN)];
title(['Comparison of Surrogate Performance for ',deltaN])
legend('Theoretical','Kriging Extrapolating Midpoint','Location','NorthWest')
hold off;

PerErr = abs(max(aKRG)-max(a))/max(a)*100