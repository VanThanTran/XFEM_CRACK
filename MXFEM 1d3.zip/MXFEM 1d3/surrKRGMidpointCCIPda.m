% Written By: Matthew Jon Pais, University of Florida (2011)
% Website: www.matthewpais.com
% Email: mpais@ufl.edu, matthewjpais@gmail.com

% Requires use of SURROGATES Toolbox
% FAC Viana, SURROGATES Toolbox User's Guide, Version 2.1,
% http:/sites.google.com/site/fchegury/surrogatestoolbox, 2010.

% Problem is that of fatigue crack growth for a center crack in an infinite
% plate. It is assumed that a constant crack growth increment, da has been
% used to generate a discrete history for a-dK. A kriging surrogate is fit
% to the a-dK history and used to calculate the number of cycles for each
% discrete data point using the midpoint integration method.

clear all; close all; clc; format short;

% Preliminaries
ai = 0.01;                                  % Initial crack length [m]
m  = 3.59;                                  % Paris model exponent
C  = 3.15E-11;                              % Paris model constant
S  = 78.6;                                  % Applied stress [MPa]

% Cycles predicted from crack length by Paris Law
da = ai/10; h = da;                         % Integration step size
at = ai:da:0.05;                            % Vector of crack lengths
dK = S*sqrt(pi*at);                         % Stress intensity factors
Nt = zeros(length(at),1); Nt(1) = 1;        % Nt, theoretical cycle prediction 
Nm = Nt; Nm(1) = 1;                         % Nm, kriging midpoint cycle prediction

optionKRG = srgtsKRGSetOptions(at',dK');    % Fit kriging surrogate to a-dK history
surrKRG   = srgtsKRGFit(optionKRG);         

% Back-calculate cycle numbers from a-dK history 
for i = 2:length(at)
    MP = at(i-1)+h/2;                       % Midpoint between crack lengths
    Kk = srgtsKRGEvaluate(MP,surrKRG);      % Kriging prediction for dK
    
    k2 = 1/(C*Kk^m);                        
    dN = h*k2;                              % dN between crack lengths
    
    Nm(i) = Nm(i-1)+dN;
    Nt(i) = Nt(i-1)+(at(i)^(1-m/2)-at(i-1)^(1-m/2))/(C*(1-m/2)*(S*sqrt(pi))^m);
end

% Plot the results
figure; hold on; box on;
plot(Nt,at*1000,'k')
plot(Nm,at*1000,'--r')
xlabel('Number of Cycles'); ylabel('Crack Length, mm')
legend('Theoretical','Kriging Interpolating Midpoint','Location','NorthWest')
hold off;

% Percent error in final cycle number
PerErr = abs(Nm(length(at))-Nt(length(at)))/Nt(length(at))*100